hybridauth-drupaloauth2
=======================

Drupal OAuth2 provider for the library HybridAuth.
