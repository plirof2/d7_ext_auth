---
layout: default
title: "Migrating from Hybridauth 2 to Hybridauth 3"
---

Migrating from Hybridauth 2 to Hybridauth 3
===========================================

<br />

**ToDo..**

<style>
footer {
  position: fixed;
  bottom: 0;
  width: 100%;
}
</style>
