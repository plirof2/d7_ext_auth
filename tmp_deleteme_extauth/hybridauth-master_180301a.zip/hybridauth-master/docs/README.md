Current documentation covers a large chunk of Hybridauth 3. 

It uses a mix of simple markdown and html code and Jekyll as rendering engine, and it's meant to be hosted on https://hybridauth.github.io.
